# CRUD-Operations
In this we can perform simple crud opration using Mysql.
