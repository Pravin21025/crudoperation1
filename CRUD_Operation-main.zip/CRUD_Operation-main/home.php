<?php

include 'connect.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>home page</title>
</head>
<body>
<div class="container my-5">
<button  class="btn btn-primary"><a href="user.php" class="text-light">ADD user</a></button>
<button  class="btn btn-primary"><a href="display.php" class="text-light">display User</a></button>
<button  class="btn btn-primary"><a href="update.php" class="text-light">Update user</a></button>
<button  class="btn btn-primary"><a href="delete.php" class="text-light">Delete user</a></button>
</div>
</body>
</html>